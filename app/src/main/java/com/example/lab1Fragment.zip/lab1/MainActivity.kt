package com.example.lab1

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("MainActivity", "onCreate")
        setContentView(R.layout.activity_main)
        if (savedInstanceState == null) {
            openMainFragment()
        }
    }

    fun openMainFragment() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container_view, MainFragment())
            .commit()
    }

    fun openSignInFragment() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container_view, SignInFragment())
            .addToBackStack(null)
            .commit()
    }

    fun openSignUpFragment() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container_view, SignUpFragment())
            .addToBackStack(null)
            .commit()
    }

    fun openSignHomeFragment() {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container_view, HomeFragment())
            .addToBackStack(null)
            .commit()
    }

    override fun onStart() {
        super.onStart()
        Log.d("MainActivity", "onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("MainActivity", "onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("MainActivity", "onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("MainActivity", "onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("MainActivity", "onDestroy")
    }
}