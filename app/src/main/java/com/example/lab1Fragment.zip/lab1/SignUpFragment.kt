package com.example.lab1

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class SignUpFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_sign_up, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val name: EditText = view.findViewById(R.id.editTextTextUp)
        val email: EditText = view.findViewById(R.id.editTextTextEmailAddressUp)
        val password: EditText = view.findViewById(R.id.editTextNumberPasswordUp)
        val button: Button = view.findViewById(R.id.buttonUp)
        button.setOnClickListener {
            val nameText = name.text.toString()
            val emailText = email.text.toString()
            val passwordText = password.text.toString()
            if (nameText.isNotEmpty() && emailText.isNotEmpty() && passwordText.isNotEmpty()) {
                val user = User(nameText, emailText, passwordText)
                parentFragmentManager.setFragmentResult("signUpRequestKey", Bundle().apply {
                    putSerializable("user", user)
                })
                (activity as? MainActivity)?.openSignInFragment()
            } else {
                Toast.makeText(requireContext(), "All fields are required", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

