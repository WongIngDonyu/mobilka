package com.example.lab1

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import java.io.Serializable

data class User(val name: String, val email: String, val password: String) : Serializable

class SignUpActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("SignUpActivity", "onCreate")
        setContentView(R.layout.activity_sign_up)
        val name: EditText = findViewById(R.id.editTextTextUp)
        val email: EditText = findViewById(R.id.editTextTextEmailAddressUp)
        val password: EditText = findViewById(R.id.editTextNumberPasswordUp)
        val button: Button = findViewById(R.id.buttonUp)
        button.setOnClickListener {
            val nameText = name.text.toString()
            val emailText = email.text.toString()
            val passwordText = password.text.toString()
            val intent = Intent().apply {
                putExtra("name", nameText)
                putExtra("email", emailText)
                putExtra("password", passwordText)
                val user = User(nameText, emailText, passwordText)
                putExtra("user", user)
            }
            setResult(RESULT_OK, intent)
            finish()
        }
    }
    override fun onStart() {
        super.onStart()
        Log.d("SignUpActivity", "onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("SignUpActivity", "onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("SignUpActivity", "onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("SignUpActivity", "onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("SignUpActivity", "onDestroy")
    }
}