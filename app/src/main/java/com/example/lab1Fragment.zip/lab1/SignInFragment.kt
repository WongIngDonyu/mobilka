package com.example.lab1

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SignInFragment : Fragment() {

    private var regEmail: String? = null
    private var regPass: String? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_sign_in, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val email: EditText = view.findViewById(R.id.editTextTextEmailAddress)
        val password: EditText = view.findViewById(R.id.editTextNumberPassword)
        val signInButton: Button = view.findViewById(R.id.button2)
        val signUpButton: Button = view.findViewById(R.id.button3)
        parentFragmentManager.setFragmentResultListener("signUpRequestKey", this) { _, bundle ->
            val user = bundle.getSerializable("user") as? User
            if (user != null) {
                regEmail = user.email
                regPass = user.password
                email.setText(user.email)
                password.setText(user.password)
            }
        }

        signInButton.setOnClickListener {
            val emailText = email.text.toString()
            val passwordText = password.text.toString()
            if (emailText == "alo@bk.ru" && passwordText == "lol" || emailText == regEmail && passwordText == regPass) {
                (activity as? MainActivity)?.openSignHomeFragment()
            } else {
                Toast.makeText(requireContext(), "Incorrect email or password", Toast.LENGTH_SHORT).show()
            }
        }

        signUpButton.setOnClickListener {
            (activity as? MainActivity)?.openSignUpFragment()
        }
    }
}