package com.example.lab1

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.ActivityResult
import androidx.activity.result.ActivityResultCallback
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SignInActivity : AppCompatActivity() {
    private var regEmail: String? = null;
    private var regPass: String? = null;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("SignInActivity", "onCreate")
        setContentView(R.layout.activity_sign_in)
        val email: EditText = findViewById(R.id.editTextTextEmailAddress)
        val password: EditText = findViewById(R.id.editTextNumberPassword)
        val button: Button = findViewById(R.id.button2)
        val button2: Button = findViewById(R.id.button3)
        button.setOnClickListener {
            val emailText = email.text.toString()
            val passwordText = password.text.toString()
            if (emailText == "alo@bk.ru" && passwordText == "lol" || emailText == regEmail && passwordText == regPass) {
                startActivity(Intent(this, HomeActivity::class.java))
            } else {
                Toast.makeText(this, "Incorrect email or password", Toast.LENGTH_SHORT).show()
            }
        }
        button2.setOnClickListener {
            val intent = Intent(this, SignUpActivity::class.java)
            startActivityForResult(intent,1)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
                val mode = 1
                if (mode == 1) {
                    val emailFromSignUp = data?.getStringExtra("email")
                    val passwordFromSignUp = data?.getStringExtra("password")
                    regEmail = emailFromSignUp
                    regPass = passwordFromSignUp
                    findViewById<EditText>(R.id.editTextTextEmailAddress).setText(emailFromSignUp)
                    findViewById<EditText>(R.id.editTextNumberPassword).setText(passwordFromSignUp)
                } else if (mode == 2) {
                    val user = data?.getSerializableExtra("user") as? User
                    if(user!=null) {
                        regEmail = user.email
                        regPass = user.password
                        findViewById<EditText>(R.id.editTextTextEmailAddress).setText(user.email)
                        findViewById<EditText>(R.id.editTextNumberPassword).setText(user.password) }
                }
        }
    }

    override fun onStart() {
        super.onStart()
        Log.d("SignInActivity", "onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("SignInActivity", "onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("SignInActivity", "onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("SignInActivity", "onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("SignInActivity", "onDestroy")
    }
}