package com.example.lab1

import android.os.Bundle
import android.util.Log
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("HomeActivity", "onCreate")
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)
        val chatList = listOf(
            Chat("John Doe", "!Hello!", "14:48"),
            Chat("Jane Smith", "How are you?", "2:28"),
            Chat("Mike Wilson", "See you", "12:53")
        )
        val recyclerView = findViewById<RecyclerView>(R.id.RecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = ChatAdapter(chatList)
    }

    override fun onStart() {
        super.onStart()
        Log.d("HomeActivity", "onStart")
    }

    override fun onResume() {
        super.onResume()
        Log.d("HomeActivity", "onResume")
    }

    override fun onPause() {
        super.onPause()
        Log.d("HomeActivity", "onPause")
    }

    override fun onStop() {
        super.onStop()
        Log.d("HomeActivity", "onStop")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("HomeActivity", "onDestroy")
    }
}